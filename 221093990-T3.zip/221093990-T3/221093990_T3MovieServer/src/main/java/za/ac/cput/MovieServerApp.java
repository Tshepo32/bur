
package za.ac.cput;

import za.ac.cput.Domain.MovieServer;

/**
 *
 * @author 221093990
 */
public class MovieServerApp {
    public static void main(String[] args) {
        MovieServer ms = new MovieServer();
        ms.processClient();
    }
}
