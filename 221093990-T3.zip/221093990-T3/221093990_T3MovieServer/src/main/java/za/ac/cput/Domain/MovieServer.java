
package za.ac.cput.Domain;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 221093990
 */
public class MovieServer {
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private Object receivedObject;
    private List<Movie> movieRecords = new ArrayList<>();
//In the constructor listen for incoming client connections 
    public MovieServer() {
        try {
            serverSocket = new ServerSocket(12345, 1);
            System.out.println("Server listening on port 12345");

            clientSocket = serverSocket.accept();
            System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());
            getStreams();
            processClient();

        } catch (IOException ioe) {
            System.out.println("Exception: " + ioe.getMessage());
        }
    }
    
    public void getStreams() {
        try {
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            in = new ObjectInputStream(clientSocket.getInputStream());
        } catch (IOException e) {
            System.out.println("IOException: " + e.getMessage());
        }
    }
    
    public void processClient() {
        try {
            while (true) {
                receivedObject = in.readObject();
                if (receivedObject instanceof String) {
                    String request = (String) receivedObject;
                    if (request.equalsIgnoreCase("add record")) {
                        Movie movieToAdd = (Movie) in.readObject();
                        
                        boolean movieExists = false;
                        for (Movie movie : movieRecords) {
                            if (movie.getMovieGenre().equals(movieToAdd.getMovieGenre())) {
                                movieExists = true;
                                break;
                            }
                        }
                        
                        if (!movieExists) {
                            movieRecords.add(movieToAdd);
                            out.writeObject("Add");
                            out.flush();
                        }
                    } else if (request.equalsIgnoreCase("get_records")) {
                        out.writeObject(movieRecords);
                        out.flush();
                    }
                    if (request.equalsIgnoreCase("SEARCH")) {
                        String searchMovie = (String) in.readObject();
                        Movie foundMovie = null;

                        for (Movie movie : movieRecords) {
                            if (movie.getMovieGenre().equalsIgnoreCase(searchMovie)) {
                                foundMovie = movie;
                                break;
                            }
                        }

                        out.writeObject(foundMovie);
                        out.flush();
                    } 

                }

            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Movie.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        getStreams();
        closeConnection();
    }
    
    private void closeConnection() {
        try {
            out.close();
            in.close();
            clientSocket.close();
            serverSocket.close();
        } catch (IOException e) {
            System.out.println("IOException: " + e.getMessage());
        }
    }
}
