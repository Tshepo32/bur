
package za.ac.cput;

import za.ac.cput.GUI.MovieClient;

/**
 *
 * @author 221093990
 */
public class MovieClientApp {
    public static void main(String[] args) {
        MovieClient mc = new MovieClient();
        mc.setGUI();
    }
}
